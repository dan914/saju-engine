
**Applied Basis:** Day boundary=23:00; Time basis=STD (IANA tzdb, DST auto); Month=Solar-term entry; Year=Lichun. Engine=KR_classic v1.4. Evidence log available upon request.
